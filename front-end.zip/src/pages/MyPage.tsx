import React from 'react';

const Mypage = () => {
  return <h1>마이페이지입니다.</h1>;
};

export default Mypage;
