import React from 'react';

const RegisterPage = () => {
  return <h1>회원가입 페이지</h1>;
};

export default RegisterPage;
