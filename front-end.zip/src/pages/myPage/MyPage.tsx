const MyPage = () => {
  return (
    <>
      <h1>마이 페이지 입니다.</h1>
    </>
  );
};

export default MyPage;
